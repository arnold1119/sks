#include "Test.h"



Test::Test() {
    a = 100;
}